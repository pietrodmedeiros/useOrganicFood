# OrganicFood Project

![logo](https://raw.githubusercontent.com/JuliaMendes/organicFood/main/img/logo-verde.png)

### Acesse o Projeto OrganicFood [clicando aqui](https://isorganicfood.netlify.app/)
------------------------------

* Objetivos
  * Auxiliar e expandir a ONG ChildFund Brasil.
  
  * Aumentar o consumo de produtos orgânicos.
  
  * Aumentar o número de hortas orgânicas da agricultura familiar dentro de centros urbanos.
<br>

* Vídeo
  * Acesse o vídeo demonstração do projeto [clicando aqui](https://youtu.be/pS-Y_RTcBvU)
##### Projeto criado durante a disciplina _Projeto Integrador 2022/1 - SENAC_ 
* Integrantes do Grupo
  * CLEYTON CARLOS DA SILVA
  * GABRIEL NUNES DA SILVA
  * JULIA DE PAIVA MENDES DA SILVA
  * JULIANA FRANCISCA DANIEL MOISES
  * MICHELE CRISTINA NUNES DA SILVA
  * PIETRO DE DEUS MEDEIROS
  * SABRINA DE BRITO RIBEIRO
  * VICTOR EMANOEL DOS SANTOS
